package model.service;

import model.entities.Contract;

public class ContractService {
    public void processContract(Contract contract, int months) {
        System.out.println("Já volto...");
    }
}
