package entities.enums;

public enum Color {
    BLACK,
    BLUE,
    RED;
}
