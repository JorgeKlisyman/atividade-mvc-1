package module.exception;

public class LimitException extends Exception {
    public LimitException(String msg) {
        super(msg);
    }
}
