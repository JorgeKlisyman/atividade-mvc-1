package entities.enums;

public enum WorkerLevel {
    JUNIOR,
    MID_LEVEL,
    SENIOR;

}
