package exception;

public class ContaJaExisteException extends Exception {
    public ContaJaExisteException(String msg){
        super(msg);
    }
}
