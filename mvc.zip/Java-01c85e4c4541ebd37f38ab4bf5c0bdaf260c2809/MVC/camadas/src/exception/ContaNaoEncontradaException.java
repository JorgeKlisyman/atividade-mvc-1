package exception;

public class ContaNaoEncontradaException extends Exception {
    public ContaNaoEncontradaException(String msg) {
        super(msg);
    }
}
