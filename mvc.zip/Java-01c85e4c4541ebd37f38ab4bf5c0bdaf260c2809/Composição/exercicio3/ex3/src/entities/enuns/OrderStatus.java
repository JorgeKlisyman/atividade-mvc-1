package entities.enuns;

public enum OrderStatus {
    PEDING_PAYMENT,
    PROCESSING,
    SHIPPED,
    DELIVERED;
}
