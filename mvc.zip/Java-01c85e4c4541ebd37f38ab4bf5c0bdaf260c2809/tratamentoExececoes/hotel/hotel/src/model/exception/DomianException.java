package model.exception;

public class DomianException extends Exception {
    public DomianException(String msg) {
        super(msg);
    }
}
